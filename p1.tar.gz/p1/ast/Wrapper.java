package ast;
public class Wrapper {
    public String type;
    public int counter;
}